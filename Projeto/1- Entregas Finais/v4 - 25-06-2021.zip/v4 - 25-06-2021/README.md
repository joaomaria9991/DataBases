# Entrega 25-06-2021
- Fix typos "TorrentTracker - SQL Storage Procedures with Transactions.sql"
- Update Relatório
- Add "Diagrama Entidade-Relação.png"
- Add "Modelo Relacional.png"
- Add Source Code GUI

# Entrega 24-06-2021
- Add Relatório
- Organização Código SQL em varios arquivos
- Add Video no Powerpoint

# Entrega 22-06-2021
- Apresentação powerpoint
- Código SQL

