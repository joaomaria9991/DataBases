﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TorrentTracker
{
    class progdata
    {
        String IMDB_Nome;
        String IMDB_Ano;
        String IMDB_Classificacao;
        String IMDB_Sinopse;
        String Episodio;
        String Temporada;

        public string IMDB_Nome1 { get => IMDB_Nome; set => IMDB_Nome = value; }
        public string IMDB_Ano1 { get => IMDB_Ano; set => IMDB_Ano = value; }
        public string IMDB_Classificacao1 { get => IMDB_Classificacao; set => IMDB_Classificacao = value; }
        public string IMDB_Sinopse1 { get => IMDB_Sinopse; set => IMDB_Sinopse = value; }
        public string Episodio1 { get => Episodio; set => Episodio = value; }
        public string Temporada1 { get => Temporada; set => Temporada = value; }
    }
}
