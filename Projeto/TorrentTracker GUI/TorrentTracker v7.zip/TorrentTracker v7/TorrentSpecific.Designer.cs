﻿
namespace TorrentTracker
{
    partial class TorrentSpecific
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TorrentSpecific));
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.serie5 = new System.Windows.Forms.Label();
            this.serie6 = new System.Windows.Forms.Label();
            this.serie7 = new System.Windows.Forms.Label();
            this.serie8 = new System.Windows.Forms.Label();
            this.serie1 = new System.Windows.Forms.TextBox();
            this.serie2 = new System.Windows.Forms.TextBox();
            this.serie3 = new System.Windows.Forms.TextBox();
            this.serie4 = new System.Windows.Forms.TextBox();
            this.serie9 = new System.Windows.Forms.Label();
            this.serie10 = new System.Windows.Forms.TextBox();
            this.os1 = new System.Windows.Forms.TextBox();
            this.os = new System.Windows.Forms.Label();
            this.t = new System.Windows.Forms.Label();
            this.ep = new System.Windows.Forms.Label();
            this.ep1 = new System.Windows.Forms.TextBox();
            this.t1 = new System.Windows.Forms.TextBox();
            this.progname = new System.Windows.Forms.Label();
            this.progname1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 182);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome do Torrent";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(151, 180);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(428, 23);
            this.textBox1.TabIndex = 1;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(789, 597);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(108, 44);
            this.button1.TabIndex = 2;
            this.button1.Text = "Sair";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(46, 239);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 15);
            this.label5.TabIndex = 15;
            this.label5.Text = "Seeders:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(360, 238);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 15);
            this.label6.TabIndex = 16;
            this.label6.Text = "Leechers:";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 15;
            this.listBox1.Location = new System.Drawing.Point(263, 409);
            this.listBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(579, 184);
            this.listBox1.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(263, 384);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 15);
            this.label2.TabIndex = 18;
            this.label2.Text = "Comentários:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(150, 239);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(141, 23);
            this.textBox2.TabIndex = 19;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(438, 236);
            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(141, 23);
            this.textBox3.TabIndex = 20;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 326);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 15);
            this.label3.TabIndex = 21;
            this.label3.Text = "Data de Adição";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(135, 324);
            this.textBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(184, 23);
            this.textBox4.TabIndex = 22;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(623, 180);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 15);
            this.label4.TabIndex = 23;
            this.label4.Text = "Tamanho";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(701, 174);
            this.textBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(141, 23);
            this.textBox5.TabIndex = 24;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // serie5
            // 
            this.serie5.AutoSize = true;
            this.serie5.Location = new System.Drawing.Point(616, 219);
            this.serie5.Name = "serie5";
            this.serie5.Size = new System.Drawing.Size(105, 15);
            this.serie5.TabIndex = 27;
            this.serie5.Text = "Tipo de Conteúdo:";
            this.serie5.Click += new System.EventHandler(this.serie5_Click);
            // 
            // serie6
            // 
            this.serie6.AutoSize = true;
            this.serie6.Location = new System.Drawing.Point(616, 262);
            this.serie6.Name = "serie6";
            this.serie6.Size = new System.Drawing.Size(71, 15);
            this.serie6.TabIndex = 28;
            this.serie6.Text = "IMDB Name";
            // 
            // serie7
            // 
            this.serie7.AutoSize = true;
            this.serie7.Location = new System.Drawing.Point(617, 324);
            this.serie7.Name = "serie7";
            this.serie7.Size = new System.Drawing.Size(61, 15);
            this.serie7.TabIndex = 29;
            this.serie7.Text = "IMDB Ano";
            // 
            // serie8
            // 
            this.serie8.AutoSize = true;
            this.serie8.Location = new System.Drawing.Point(617, 372);
            this.serie8.Name = "serie8";
            this.serie8.Size = new System.Drawing.Size(107, 15);
            this.serie8.TabIndex = 30;
            this.serie8.Text = "IMDB Classificação";
            // 
            // serie1
            // 
            this.serie1.Location = new System.Drawing.Point(707, 214);
            this.serie1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.serie1.Name = "serie1";
            this.serie1.Size = new System.Drawing.Size(135, 23);
            this.serie1.TabIndex = 31;
            this.serie1.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // serie2
            // 
            this.serie2.Location = new System.Drawing.Point(702, 260);
            this.serie2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.serie2.Name = "serie2";
            this.serie2.Size = new System.Drawing.Size(140, 23);
            this.serie2.TabIndex = 32;
            // 
            // serie3
            // 
            this.serie3.Location = new System.Drawing.Point(703, 322);
            this.serie3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.serie3.Name = "serie3";
            this.serie3.Size = new System.Drawing.Size(140, 23);
            this.serie3.TabIndex = 33;
            // 
            // serie4
            // 
            this.serie4.Location = new System.Drawing.Point(755, 366);
            this.serie4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.serie4.Name = "serie4";
            this.serie4.Size = new System.Drawing.Size(58, 23);
            this.serie4.TabIndex = 34;
            // 
            // serie9
            // 
            this.serie9.AutoSize = true;
            this.serie9.Location = new System.Drawing.Point(31, 384);
            this.serie9.Name = "serie9";
            this.serie9.Size = new System.Drawing.Size(73, 15);
            this.serie9.TabIndex = 35;
            this.serie9.Text = "Release Type";
            // 
            // serie10
            // 
            this.serie10.Location = new System.Drawing.Point(119, 384);
            this.serie10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.serie10.Name = "serie10";
            this.serie10.Size = new System.Drawing.Size(98, 23);
            this.serie10.TabIndex = 36;
            this.serie10.TextChanged += new System.EventHandler(this.serie10_TextChanged);
            // 
            // os1
            // 
            this.os1.Location = new System.Drawing.Point(119, 408);
            this.os1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.os1.Name = "os1";
            this.os1.Size = new System.Drawing.Size(98, 23);
            this.os1.TabIndex = 37;
            // 
            // os
            // 
            this.os.AutoSize = true;
            this.os.Location = new System.Drawing.Point(31, 410);
            this.os.Name = "os";
            this.os.Size = new System.Drawing.Size(25, 15);
            this.os.TabIndex = 38;
            this.os.Text = "OS:";
            // 
            // t
            // 
            this.t.AutoSize = true;
            this.t.Location = new System.Drawing.Point(360, 272);
            this.t.Name = "t";
            this.t.Size = new System.Drawing.Size(69, 15);
            this.t.TabIndex = 39;
            this.t.Text = "Temporada:";
            // 
            // ep
            // 
            this.ep.AutoSize = true;
            this.ep.Location = new System.Drawing.Point(360, 332);
            this.ep.Name = "ep";
            this.ep.Size = new System.Drawing.Size(55, 15);
            this.ep.TabIndex = 40;
            this.ep.Text = "Episódio:";
            // 
            // ep1
            // 
            this.ep1.Location = new System.Drawing.Point(360, 358);
            this.ep1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ep1.Name = "ep1";
            this.ep1.Size = new System.Drawing.Size(98, 23);
            this.ep1.TabIndex = 41;
            // 
            // t1
            // 
            this.t1.Location = new System.Drawing.Point(360, 289);
            this.t1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.t1.Name = "t1";
            this.t1.Size = new System.Drawing.Size(98, 23);
            this.t1.TabIndex = 42;
            // 
            // progname
            // 
            this.progname.AutoSize = true;
            this.progname.Location = new System.Drawing.Point(35, 452);
            this.progname.Name = "progname";
            this.progname.Size = new System.Drawing.Size(40, 15);
            this.progname.TabIndex = 43;
            this.progname.Text = "Nome";
            // 
            // progname1
            // 
            this.progname1.Location = new System.Drawing.Point(93, 450);
            this.progname1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progname1.Name = "progname1";
            this.progname1.Size = new System.Drawing.Size(112, 23);
            this.progname1.TabIndex = 44;
            // 
            // TorrentSpecific
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(903, 645);
            this.Controls.Add(this.progname1);
            this.Controls.Add(this.progname);
            this.Controls.Add(this.t1);
            this.Controls.Add(this.ep1);
            this.Controls.Add(this.ep);
            this.Controls.Add(this.t);
            this.Controls.Add(this.os);
            this.Controls.Add(this.os1);
            this.Controls.Add(this.serie10);
            this.Controls.Add(this.serie9);
            this.Controls.Add(this.serie4);
            this.Controls.Add(this.serie3);
            this.Controls.Add(this.serie2);
            this.Controls.Add(this.serie1);
            this.Controls.Add(this.serie8);
            this.Controls.Add(this.serie7);
            this.Controls.Add(this.serie6);
            this.Controls.Add(this.serie5);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "TorrentSpecific";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TorrentSpecific";
            this.Load += new System.EventHandler(this.TorrentSpecific_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label serie5;
        private System.Windows.Forms.Label serie6;
        private System.Windows.Forms.Label serie7;
        private System.Windows.Forms.Label serie8;
        private System.Windows.Forms.TextBox serie1;
        private System.Windows.Forms.TextBox serie2;
        private System.Windows.Forms.TextBox serie3;
        private System.Windows.Forms.TextBox serie4;
        private System.Windows.Forms.Label serie9;
        private System.Windows.Forms.TextBox serie10;
        private System.Windows.Forms.TextBox os1;
        private System.Windows.Forms.Label os;
        private System.Windows.Forms.Label t;
        private System.Windows.Forms.Label ep;
        private System.Windows.Forms.TextBox ep1;
        private System.Windows.Forms.TextBox t1;
        private System.Windows.Forms.Label progname;
        private System.Windows.Forms.TextBox progname1;
    }
}