﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TorrentTracker
{
    class imdb
    {
        String NomeGame;
        String OS;

        public string NomeGame1 { get => NomeGame; set => NomeGame = value; }
        public string OS1 { get => OS; set => OS = value; }
    }
}
